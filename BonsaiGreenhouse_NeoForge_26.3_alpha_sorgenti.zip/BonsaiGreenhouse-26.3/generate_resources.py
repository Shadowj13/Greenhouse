#!/usr/bin/env python3
"""Generate 26.3 blockstates/recipes/assets for the first playable alpha."""
from pathlib import Path
import json
ROOT=Path(__file__).parent/'src/main/resources'
A=ROOT/'assets/bonsai_greenhouse'
D=ROOT/'data/bonsai_greenhouse'
plants=[
 'oak','spruce','birch','jungle','acacia','dark_oak','cherry','mangrove','pale_oak',
 'azalea','flowering_azalea','poplar_red','poplar_orange','poplar_yellow','crimson_fungus','warped_fungus',
 'wheat','carrots','potatoes','beetroot','nether_wart','cocoa','cactus','sugar_cane','bamboo','pumpkin','melon',
 'sweet_berries','red_mushroom','brown_mushroom']

def dump(path, obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

for block in ('bonsai_greenhouse','hopping_greenhouse'):
    components=[{'apply': {'model': 'bonsai_greenhouse:block/'+block}}]
    for crop in plants:
        for stage in range(4):
            components.append({'when': {'crop':crop, 'stage':str(stage)},
                               'apply': {'model':'bonsai_greenhouse:block/plants/'+crop+'_stage_'+str(stage)}})
    dump(A/'blockstates'/f'{block}.json', {'multipart':components})
    dump(A/'items'/f'{block}.json', {'model': {'type':'minecraft:model','model':'bonsai_greenhouse:block/'+block}})

# 26.3 item tag for vanilla wooden slabs (oak, spruce, poplar, etc.).
# minecraft:wooden_slabs covers all native wood species.
dump(D/'recipe/bonsai_greenhouse.json',{
 'type':'minecraft:crafting_shaped','category':'misc','pattern':['GGG','GPG','SSS'],
 'key':{'G':'minecraft:glass_pane','P':'minecraft:flower_pot','S':'#minecraft:wooden_slabs'},
 'result':{'id':'bonsai_greenhouse:bonsai_greenhouse','count':1}
})
dump(D/'recipe/hopping_greenhouse.json',{
 'type':'minecraft:crafting_shaped','category':'misc','pattern':['GGG','GSG','BHB'],
 'key':{'G':'minecraft:glass_pane','S':'bonsai_greenhouse:bonsai_greenhouse',
        'B':'minecraft:barrel','H':'minecraft:hopper'},
 'result':{'id':'bonsai_greenhouse:hopping_greenhouse','count':1}
})
# Simple vanilla loot tables for breakage of the outer block. BE contents are still
# TODO: drop separately using custom logic instead of silently deleting them.
for block in ('bonsai_greenhouse','hopping_greenhouse'):
    dump(D/'loot_table/blocks'/f'{block}.json', {
      'type':'minecraft:block','pools':[{'rolls':1,'entries':[{'type':'minecraft:item','name':'bonsai_greenhouse:'+block}]}]
    })
for locale,labels in {
  'it_it': ['Serra Bonsai','Serra Bonsai automatica','Bonsai Greenhouse'],
  'en_us': ['Bonsai Greenhouse','Hopping Greenhouse','Bonsai Greenhouse']
}.items():
    dump(A/'lang'/f'{locale}.json',{
      'block.bonsai_greenhouse.bonsai_greenhouse':labels[0],
      'block.bonsai_greenhouse.hopping_greenhouse':labels[1],
      'itemGroup.bonsai_greenhouse':labels[2]})
print('Generated',len(plants),'plant types x 4 stages and all static resources.')
