# Bonsai Greenhouse — NeoForge 26.3

**Sorgenti alpha 0.1.0, non ancora compilati né testati nel client Minecraft.**

Questa cartella è la prima implementazione Java progettata sulle API NeoForge 26.3 e contiene gli asset approvati. Non chiamare il progetto un file `.jar` giocabile finché `gradlew build` non termina correttamente.

## Windows — come tentare la prima build

1. Installa **JDK 25** (oppure configura il download automatico del toolchain tramite Gradle) e Minecraft Java 26.3 + NeoForge 26.3.
2. Estrai lo ZIP del progetto in una cartella senza spazi strani.
3. Apri PowerShell in quella cartella ed esegui `powershell -ExecutionPolicy Bypass -File .\build-windows.ps1`.
4. Lo script recupera il **Gradle wrapper ufficiale** del MDK NeoForge 26.3 qualora mancante, poi esegue `gradlew.bat build`.
5. Se Gradle segnala errori API, occorre correggerli usando l'output della compilazione: questa alpha non è stata compilata nell'ambiente corrente per l'assenza di Java 25 e connessione alle dipendenze.
6. Se la build riesce, copia il JAR risultante da `build/libs/` nella cartella `mods` dell'istanza Minecraft 26.3 con NeoForge 26.3, **prima su un nuovo mondo di prova**.
7. Puoi avviare il client di sviluppo con `gradlew.bat runClient`.

## Contenuti implementati nel codice della prima alpha

- Registrazione dei due blocchi, relativi item e BlockEntity.
- Due ricette 3×3: **5 pannelli di vetro + 1 vaso da fiori + 3 lastre di legno** per la base (tag `minecraft:wooden_slabs`); **5 pannelli + 1 serra base + 2 barili + 1 tramoggia** per la versione automatica.
- Le 30 tipologie di piante del pacchetto modelli (poplar in alpha usa la variante rossa, dato che vanilla ha un solo `poplar_sapling`).
- Crescita server ogni tick: alberi 45 secondi, colture comuni 30 secondi, speciali 45 secondi; 4 stadi visualizzati in blockstates multipart.
- Drop principali garantiti, secondari casuali.
- Bonus della farina di ossa: **×2 per 4 cicli** consumando una dose.
- Inventario automatico di **9 slot**, sospensione raccolta con inventario pieno e trasferimento nel contenitore vanilla sottostante.
- Salvataggio di semi, terreni, fertilizzante, raccolti, ciclo e raccolti in attesa.
- Recupero dei contenuti rompendo il blocco da parte di un giocatore.

## Controlli provvisori in alpha

Per il primo collaudo si usa **l'interfaccia vanilla di cassa a tre righe** invece della GUI custom progettata:
- Apri a mano vuota con clic destro.
- Prima riga: slot 1 terreno, slot 2 seme/alberello, slot 3 farina di ossa. Le altre caselle della prima riga sono vuote e non accettano oggetti.
- Seconda riga: **9 slot** di produzione solo per l'Hopping Greenhouse.
- Terza riga: non utilizzata; non accetta oggetti.
- **Maiusc + clic destro** sulla serra normale matura per la raccolta manuale.
- Nessun bottone `Raccogli` né barra di progresso nella GUI vanilla: sono previsti per un prossimo aggiornamento.

## Limitazioni note da verificare in Minecraft

- **NON COMPILATA** e non eseguita: nomi API e formati del materiale 26.3 vanno convalidati con una build reale.
- Il trasferimento diretto funziona solo con BlockEntity che implementano `Container` vanilla; le capability avanzate di stoccaggio NeoForge saranno aggiunte in seguito.
- L'ingresso degli oggetti dall'alto/lati usa `WorldlyContainer`; verificare comportamento delle tramogge.
- Il substrato mostrato nel modello base è ancora la texture di terra dimostrativa; cambierà con un renderer dinamico futuro.
- Il vetro dei modelli JSON richiede verifica del materiale/render layer in gioco.
- Piante e prodotti delle nuove specie 26.3 vanno controllati; alcuni asset poplar hanno tre modelli ma l'oggetto vanilla è uno solo.
- Mancano particelle, animazioni morbide, GUI personalizzata e configurazione esterna dei drop.
- Per il primo collaudo si consiglia un mondo di prova, non un salvataggio importante.

## Layout risorse

`src/main/java/it/bonsaigreenhouse`: logica NeoForge in Java.
`src/main/resources/assets/bonsai_greenhouse`: modelli, texture, blockstates, item models, traduzioni.
`src/main/resources/data/bonsai_greenhouse`: crafting e loot tables.
`blockbench`: modelli modificabili (soltanto per editing, non vengono inclusi nel JAR).
`generate_resources.py`: rigenera blockstates e file ricette a partire dalla lista delle specie.

## Strumenti

- MDK di riferimento: https://github.com/NeoForgeMDKs/MDK-26.3-NeoGradle
- NeoForge docs: https://docs.neoforged.net/
