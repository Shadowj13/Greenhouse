# Checklist alpha 0.1 — Minecraft 26.3

Prima di provarla in un mondo importante, esegui questi test in un nuovo mondo Creative. Le voci NON sono già state testate.

1. **Caricamento mod:** il gioco si avvia senza errori registrazione blocchi, JSON/BlockState o menu.
2. **Ricette:** 5 pannelli di vetro + vaso da fiori + 3 lastre di legno (anche poplar); Hopping con 5 pannelli, serra normale, due barili, tramoggia.
3. **Visualizzazione:** vetro trasparente, terra dimostrativa, quercia nei 4 stadi. Prova `/give @s bonsai_greenhouse:bonsai_greenhouse` e `/give @s bonsai_greenhouse:hopping_greenhouse`.
4. **Interazione:** clic destro a mano vuota apre una GUI vanilla a 3 righe. Metti terra nel primo slot e alberello di quercia nel secondo.
5. **Crescita:** dopo ~45 secondi a 20 TPS la quercia matura. Maiusc + clic destro la raccoglie (2 tronchi garantiti), il ciclo riparte.
6. **Fertilizzazione:** metti farina di ossa nello slot 3, verifica i 4 cicli in ~22,5 secondi ciascuno e consumo di una unità per gruppo.
7. **Colture:** grano con semi e terra, 2 grani a ciclo ogni ~30 secondi; verruche del Nether con sabbia delle anime, 2 verruche ogni ~45 secondi.
8. **Hopping:** inventario di produzione seconda riga (9 slot), prodotti raccolti automaticamente. Posiziona una cassa sotto e verifica il trasferimento.
9. **Inventario pieno:** riempi i 9 slot e blocca la cassa, verifica che la serra resti matura e non perda drop.
10. **Salvataggio:** esci dal mondo, rientra e controlla inventario, substrato, pianta e stato fertilizzante.
11. **Rottura:** rompi i vasi da giocatore e verifica recupero di semi/terra/farina/prodotti.

**Problemi attesi e non risolti:** GUI personalizzata assente, niente barra interna, niente renderer del terreno dinamico, compatibilità inventari avanzati NeoForge ancora da implementare, shader del vetro da verificare, possibile adattamento API richiesto dal compilatore NeoForge 26.3.
