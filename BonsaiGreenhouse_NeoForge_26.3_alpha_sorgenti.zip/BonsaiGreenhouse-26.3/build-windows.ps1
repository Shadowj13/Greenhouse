# Bonsai Greenhouse build helper for Windows PowerShell (run from extracted project folder).
# It fetches only the OFFICIAL NeoForge MDK wrapper if absent, then builds the mod.
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (!(Test-Path "gradle/wrapper/gradle-wrapper.jar")) {
    Write-Host "Downloading official NeoForge 26.3 MDK Gradle wrapper..."
    $url = "https://github.com/NeoForgeMDKs/MDK-26.3-NeoGradle/archive/refs/heads/main.zip"
    $archive = Join-Path $env:TEMP "bonsai-neoforge-mdk.zip"
    $folder = Join-Path $env:TEMP "bonsai-neoforge-mdk-wrapper"
    Invoke-WebRequest -Uri $url -OutFile $archive
    if (Test-Path $folder) { Remove-Item -Recurse -Force $folder }
    Expand-Archive -Path $archive -DestinationPath $folder
    $template = Join-Path $folder "MDK-26.3-NeoGradle-main"
    New-Item -ItemType Directory -Force -Path "gradle/wrapper" | Out-Null
    Copy-Item "$template/gradle/wrapper/*" "gradle/wrapper/" -Force
    Copy-Item "$template/gradlew.bat" "gradlew.bat" -Force
    Copy-Item "$template/gradlew" "gradlew" -Force
}
Write-Host "Building Bonsai Greenhouse with Gradle..."
& .\gradlew.bat build --stacktrace
if ($LASTEXITCODE -ne 0) { throw "Build failed. Check the error log shown above." }
Write-Host "Build completed. Check build/libs for the mod JAR."
